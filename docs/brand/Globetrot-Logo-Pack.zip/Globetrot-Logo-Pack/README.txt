GLOBETROT CARGOLINK INTERNATIONAL - LOGO PACK

01-Full-Logo
  Colour_Transparent_for-light-backgrounds.png  Navy lettering. Use on white or light backgrounds (letters, invoices, documents).
  Colour_Transparent_for-dark-backgrounds.png   White lettering. Use on navy, black or dark photos.
  On-White.png / On-Navy.png                    Ready-made versions with background and safe space around the logo.

02-Icon
  The GT globe mark on its own. Use where space is small or square (app icons, stamps, profile pictures).

03-Print-Vector-PDF
  Vector files for printers and signage. They scale to any size without losing quality.

04-Web-and-Social
  Social media profile picture (1080 x 1080) and website favicons.

BRAND COLOURS
  Harbour Navy   #060C17   RGB 6, 12, 23
  Globe Navy     #0B1628   RGB 11, 22, 40
  Signal Amber   #F3A43B   RGB 243, 164, 59
  Globe Blue     #4F86D6   RGB 79, 134, 214
  White          #FFFFFF

FONT
  Archivo (free, Google Fonts)

USAGE
  Keep clear space around the logo at least the height of the letter "G".
  Do not stretch, recolour, rotate or add effects to the logo.
